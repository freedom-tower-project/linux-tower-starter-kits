#!/bin/bash

# Master Setup Script - Brandon's Linux Tower Copy (Full GUI Edition)
# Created with Caelum, April 2025

set -e  # Exit on error

# Update package list
sudo apt update

# Install system core tools
sudo apt install -y \
  cpufrequtils \
  bashtop \
  lm-sensors \
  nvme-cli \
  smartmontools \
  util-linux \
  unattended-upgrades \
  curl \
  cron \
  sudo \
  flameshot \
  flatpak \
  gnome-software \
  gnome-software-plugin-flatpak \
  synaptic \
  xfce4 \
  xfce4-goodies \
  lightdm

# Set LightDM as default display manager
echo "/usr/sbin/lightdm" | sudo tee /etc/X11/default-display-manager

# Set CPU governor to schedutil
sudo cpufreq-set -r -g schedutil

echo 'GOVERNOR="schedutil"' | sudo tee /etc/default/cpufrequtils
sudo systemctl enable cpufrequtils
sudo systemctl start cpufrequtils

# Set up automatic RAM cleaning
sudo bash -c 'cat > /usr/local/bin/cleanram <<EOF
#!/bin/bash
sync; echo 3 | sudo tee /proc/sys/vm/drop_caches
EOF'
sudo chmod +x /usr/local/bin/cleanram

# Add RAM cleaning cronjob (every hour)
(sudo crontab -l 2>/dev/null; echo "0 * * * * /usr/local/bin/cleanram") | sudo crontab -

# Enable automatic security upgrades
sudo dpkg-reconfigure --priority=low unattended-upgrades

# Install Netdata (direct GitHub install)
bash <(curl -Ss https://raw.githubusercontent.com/netdata/netdata/master/packaging/installer/kickstart.sh)

# Enable Netdata on boot
sudo systemctl enable netdata
sudo systemctl start netdata

# Set up SSD/NVMe automatic TRIM
sudo systemctl enable fstrim.timer
sudo systemctl start fstrim.timer

# Run sensors-detect automatically
sudo sensors-detect --auto

# Enable Flathub as a source for Flatpak apps
sudo flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo

# Done!
echo "\n\n✅ FULL GUI MASTER SETUP COMPLETE! \n\nReboot, login to XFCE desktop, and your system is ready!\nNetdata Dashboard: http://YOUR-LAPTOP-IP:19999"
