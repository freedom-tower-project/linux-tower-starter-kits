
========================================
Brandon's Linux Tower Copy - Full GUI Setup Package
========================================

Built with Caelum, April 2025

This package will automatically configure a fresh Ubuntu Server install with:
- RAM auto-cleaning (hourly)
- CPU scaling governor set to schedutil
- Netdata live monitoring dashboard (http://YOUR-IP:19999)
- Bashtop system monitor (terminal-based)
- Full drive health monitoring (smartmontools, nvme-cli)
- Auto security updates (unattended-upgrades)
- NVMe/SSD automatic TRIM
- Sensor auto-detection for temperatures
- XFCE4 Desktop Environment
- LightDM graphical login manager
- Flameshot Screenshot Tool
- Flatpak + Flathub integration
- GNOME Software Center + Synaptic Package Manager

--------------------------------------------------
How to Use:

1. Transfer 'master_setup_full_gui_package.zip' to your target machine.
2. Unzip it:
   unzip master_setup_full_gui_package.zip
3. Enter the directory:
   cd master_setup_full_gui_package
4. Make the script executable:
   chmod +x master_setup_full_gui.sh
5. Run the setup script:
   sudo ./master_setup_full_gui.sh

After installation:
- Reboot your machine.
- Login through the LightDM graphical login screen.
- XFCE desktop environment will be ready.
- App Stores (Flatpak + APT) will be available.
- System will be fully optimized and monitored.

--------------------------------------------------

Victory belongs to those who build it themselves. 🛡️👑

